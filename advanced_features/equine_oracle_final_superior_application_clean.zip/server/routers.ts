import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { predictionsRouter } from "./routers/predictions";
import { oracleRouter } from "./routers/oracleRouter";
import { getTodayRacesWithCache } from "./services/tabDataService";

export const appRouter = router({
  system: systemRouter,

  races: router({
    getTodayRaces: publicProcedure.query(async () => {
      try {
        const races = await getTodayRacesWithCache();
        return races;
      } catch (error) {
        console.error("Error fetching races:", error);
        return [];
      }
    }),
  }),

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  predictions: predictionsRouter,

  oracle: oracleRouter,
});

export type AppRouter = typeof appRouter;

