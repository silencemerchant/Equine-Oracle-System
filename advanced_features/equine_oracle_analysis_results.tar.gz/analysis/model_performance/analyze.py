#!/usr/bin/env python3.11
"""
Task 1: Model Performance Analysis
Analyzes feature importances and model contributions to the ensemble
"""

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import json
from pathlib import Path

# Set up paths
MODELS_DIR = Path('/home/ubuntu/equine_oracle/server/prediction_engine/models')
OUTPUT_DIR = Path('/home/ubuntu/analysis/model_performance')

def load_models():
    """Load all pre-trained models"""
    models = {}
    model_files = {
        'LightGBM': 'lightgbm_model.pkl',
        'XGBoost': 'xgboost_model.pkl',
        'Random Forest': 'random_forest_model.pkl',
        'Gradient Boosting': 'gradient_boosting_model.pkl',
        'LightGBM Ranker': 'lgbm_ranker_model.pkl'
    }
    
    for name, filename in model_files.items():
        try:
            models[name] = joblib.load(MODELS_DIR / filename)
            print(f"Loaded {name}")
        except Exception as e:
            print(f"Error loading {name}: {e}")
    
    return models

def analyze_feature_importances(models, feature_cols):
    """Extract and analyze feature importances from all models"""
    importances = {}
    
    for name, model in models.items():
        if hasattr(model, 'feature_importances_'):
            importances[name] = model.feature_importances_
            print(f"{name} - Top 5 features:")
            
            # Get top features
            if name == 'LightGBM Ranker':
                # Ranker has 56 features
                n_features = len(model.feature_importances_)
                indices = np.argsort(model.feature_importances_)[-5:][::-1]
                for idx in indices:
                    print(f"  Feature {idx}: {model.feature_importances_[idx]:.4f}")
            else:
                # Base models have 9 features
                indices = np.argsort(model.feature_importances_)[-5:][::-1]
                for idx in indices:
                    print(f"  {feature_cols[idx]}: {model.feature_importances_[idx]:.4f}")
            print()
    
    return importances

def plot_feature_importances(importances, feature_cols):
    """Create visualizations of feature importances"""
    # Plot for base models (9 features)
    base_models = ['LightGBM', 'XGBoost', 'Random Forest', 'Gradient Boosting']
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    axes = axes.flatten()
    
    for idx, model_name in enumerate(base_models):
        if model_name in importances:
            ax = axes[idx]
            imp = importances[model_name]
            
            # Sort by importance
            indices = np.argsort(imp)
            sorted_features = [feature_cols[i] for i in indices]
            sorted_importances = imp[indices]
            
            ax.barh(sorted_features, sorted_importances)
            ax.set_xlabel('Feature Importance')
            ax.set_title(f'{model_name} - Feature Importances')
            ax.grid(axis='x', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'feature_importances_base_models.png', dpi=300, bbox_inches='tight')
    print(f"Saved: feature_importances_base_models.png")
    plt.close()
    
    # Plot for LightGBM Ranker (top 20 features)
    if 'LightGBM Ranker' in importances:
        imp = importances['LightGBM Ranker']
        indices = np.argsort(imp)[-20:]
        
        plt.figure(figsize=(12, 10))
        plt.barh(range(20), imp[indices])
        plt.xlabel('Feature Importance')
        plt.ylabel('Feature Index')
        plt.title('LightGBM Ranker - Top 20 Feature Importances')
        plt.yticks(range(20), [f'Feature {i}' for i in indices])
        plt.grid(axis='x', alpha=0.3)
        plt.tight_layout()
        plt.savefig(OUTPUT_DIR / 'feature_importances_ranker.png', dpi=300, bbox_inches='tight')
        print(f"Saved: feature_importances_ranker.png")
        plt.close()

def compare_model_architectures(models):
    """Compare model architectures and hyperparameters"""
    comparison = {}
    
    for name, model in models.items():
        info = {
            'type': type(model).__name__,
            'n_features': model.n_features_in_ if hasattr(model, 'n_features_in_') else 'N/A'
        }
        
        if hasattr(model, 'n_estimators'):
            info['n_estimators'] = model.n_estimators
        if hasattr(model, 'max_depth'):
            info['max_depth'] = model.max_depth
        if hasattr(model, 'learning_rate'):
            info['learning_rate'] = model.learning_rate
        
        comparison[name] = info
    
    return comparison

def main():
    print("=" * 60)
    print("Task 1: Model Performance Analysis")
    print("=" * 60)
    print()
    
    # Load feature columns
    feature_cols = joblib.load(MODELS_DIR / 'feature_columns.pkl')
    print(f"Loaded {len(feature_cols)} feature columns\n")
    
    # Load models
    models = load_models()
    print()
    
    # Analyze feature importances
    print("Analyzing feature importances...")
    importances = analyze_feature_importances(models, feature_cols)
    print()
    
    # Plot feature importances
    print("Creating visualizations...")
    plot_feature_importances(importances, feature_cols)
    print()
    
    # Compare model architectures
    print("Comparing model architectures...")
    comparison = compare_model_architectures(models)
    
    # Save comparison to JSON
    with open(OUTPUT_DIR / 'model_comparison.json', 'w') as f:
        json.dump(comparison, f, indent=2)
    print(f"Saved: model_comparison.json")
    print()
    
    # Create summary report
    summary = {
        'total_models': len(models),
        'base_models': 4,
        'ranking_models': 1,
        'base_features': len(feature_cols),
        'ranker_features': 56,
        'top_features_by_model': {}
    }
    
    for name, imp in importances.items():
        if name != 'LightGBM Ranker':
            top_indices = np.argsort(imp)[-3:][::-1]
            summary['top_features_by_model'][name] = [
                {'feature': feature_cols[idx], 'importance': float(imp[idx])}
                for idx in top_indices
            ]
    
    with open(OUTPUT_DIR / 'summary.json', 'w') as f:
        json.dump(summary, f, indent=2)
    print(f"Saved: summary.json")
    
    print("\n" + "=" * 60)
    print("Task 1 Complete!")
    print("=" * 60)

if __name__ == '__main__':
    main()
