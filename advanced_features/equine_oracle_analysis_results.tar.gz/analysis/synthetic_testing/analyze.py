#!/usr/bin/env python3.11
"""
Task 6: Synthetic Data Testing
Generates test cases to validate model behavior across different scenarios
"""

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import json
from pathlib import Path

# Set up paths
MODELS_DIR = Path('/home/ubuntu/equine_oracle/server/prediction_engine/models')
OUTPUT_DIR = Path('/home/ubuntu/analysis/synthetic_testing')

def load_models_and_features():
    """Load models and feature information"""
    models = {}
    model_files = {
        'LightGBM': 'lightgbm_model.pkl',
        'XGBoost': 'xgboost_model.pkl',
        'Random Forest': 'random_forest_model.pkl',
        'Gradient Boosting': 'gradient_boosting_model.pkl'
    }
    
    for name, filename in model_files.items():
        try:
            models[name] = joblib.load(MODELS_DIR / filename)
            print(f"Loaded {name}")
        except Exception as e:
            print(f"Error loading {name}: {e}")
    
    feature_cols = joblib.load(MODELS_DIR / 'feature_columns.pkl')
    
    return models, feature_cols

def create_scenario_tests(feature_cols):
    """Create specific test scenarios"""
    scenarios = {}
    
    # Scenario 1: Strong favorite (high win rate, good recent form)
    scenarios['Strong Favorite'] = {
        'distance_numeric': 1600,
        'days_since_last_race': 14,
        'career_starts': 30,
        'avg_position_L5': 2.0,
        'win_rate_cumulative': 0.35,
        'race_class_score': 4,
        'track_popularity': 0.8,
        'avg_perf_index_L5': 1.5,
        'weighted_form_score': 85
    }
    
    # Scenario 2: Underdog (low win rate, poor recent form)
    scenarios['Underdog'] = {
        'distance_numeric': 1600,
        'days_since_last_race': 45,
        'career_starts': 25,
        'avg_position_L5': 8.5,
        'win_rate_cumulative': 0.05,
        'race_class_score': 1,
        'track_popularity': 0.4,
        'avg_perf_index_L5': -1.2,
        'weighted_form_score': 25
    }
    
    # Scenario 3: Inexperienced horse (few starts)
    scenarios['Inexperienced'] = {
        'distance_numeric': 1400,
        'days_since_last_race': 21,
        'career_starts': 3,
        'avg_position_L5': 5.0,
        'win_rate_cumulative': 0.15,
        'race_class_score': 2,
        'track_popularity': 0.6,
        'avg_perf_index_L5': 0.3,
        'weighted_form_score': 50
    }
    
    # Scenario 4: Long rest period
    scenarios['Long Rest'] = {
        'distance_numeric': 1800,
        'days_since_last_race': 75,
        'career_starts': 40,
        'avg_position_L5': 4.5,
        'win_rate_cumulative': 0.20,
        'race_class_score': 3,
        'track_popularity': 0.7,
        'avg_perf_index_L5': 0.5,
        'weighted_form_score': 60
    }
    
    # Scenario 5: Elite race
    scenarios['Elite Race'] = {
        'distance_numeric': 2000,
        'days_since_last_race': 28,
        'career_starts': 50,
        'avg_position_L5': 3.0,
        'win_rate_cumulative': 0.25,
        'race_class_score': 5,
        'track_popularity': 0.9,
        'avg_perf_index_L5': 1.0,
        'weighted_form_score': 75
    }
    
    # Scenario 6: Sprint specialist
    scenarios['Sprint Specialist'] = {
        'distance_numeric': 1000,
        'days_since_last_race': 14,
        'career_starts': 35,
        'avg_position_L5': 3.5,
        'win_rate_cumulative': 0.28,
        'race_class_score': 3,
        'track_popularity': 0.75,
        'avg_perf_index_L5': 0.8,
        'weighted_form_score': 70
    }
    
    return scenarios

def test_scenarios(models, scenarios, feature_cols):
    """Test models on different scenarios"""
    results = {}
    
    for scenario_name, features in scenarios.items():
        # Create DataFrame
        df = pd.DataFrame([features])
        df = df[feature_cols]  # Ensure correct order
        
        scenario_results = {
            'features': features,
            'predictions': {}
        }
        
        # Get predictions from each model
        for model_name, model in models.items():
            if hasattr(model, 'predict_proba'):
                pred_proba = model.predict_proba(df)[0, 1]
                scenario_results['predictions'][model_name] = float(pred_proba)
        
        # Calculate ensemble
        preds = list(scenario_results['predictions'].values())
        scenario_results['ensemble_prediction'] = float(np.mean(preds))
        
        results[scenario_name] = scenario_results
    
    return results

def test_sensitivity(models, feature_cols, base_scenario):
    """Test model sensitivity to feature changes"""
    sensitivity_results = {}
    
    # Test each feature
    for feature in feature_cols:
        feature_sensitivity = {}
        
        # Get base value
        base_value = base_scenario[feature]
        
        # Test range of values
        if feature in ['race_class_score']:
            test_values = [0, 1, 2, 3, 4, 5]
        elif feature in ['distance_numeric']:
            test_values = np.linspace(1000, 3200, 10)
        elif feature in ['days_since_last_race']:
            test_values = np.linspace(7, 90, 10)
        elif feature in ['career_starts']:
            test_values = np.linspace(1, 100, 10)
        elif feature in ['avg_position_L5']:
            test_values = np.linspace(1, 12, 10)
        elif feature in ['win_rate_cumulative']:
            test_values = np.linspace(0, 0.5, 10)
        elif feature in ['track_popularity']:
            test_values = np.linspace(0, 1, 10)
        elif feature in ['avg_perf_index_L5']:
            test_values = np.linspace(-2, 2, 10)
        elif feature in ['weighted_form_score']:
            test_values = np.linspace(0, 100, 10)
        else:
            continue
        
        predictions_by_model = {name: [] for name in models.keys()}
        
        for value in test_values:
            # Create test case
            test_case = base_scenario.copy()
            test_case[feature] = value
            
            df = pd.DataFrame([test_case])
            df = df[feature_cols]
            
            # Get predictions
            for model_name, model in models.items():
                if hasattr(model, 'predict_proba'):
                    pred = model.predict_proba(df)[0, 1]
                    predictions_by_model[model_name].append(float(pred))
        
        feature_sensitivity = {
            'test_values': [float(v) for v in test_values],
            'predictions': predictions_by_model
        }
        
        sensitivity_results[feature] = feature_sensitivity
    
    return sensitivity_results

def plot_scenario_results(results):
    """Plot scenario test results"""
    scenarios = list(results.keys())
    n_scenarios = len(scenarios)
    
    # Get model names
    model_names = list(results[scenarios[0]]['predictions'].keys())
    n_models = len(model_names)
    
    # Prepare data
    data = np.zeros((n_models + 1, n_scenarios))
    
    for i, scenario in enumerate(scenarios):
        for j, model in enumerate(model_names):
            data[j, i] = results[scenario]['predictions'][model]
        data[n_models, i] = results[scenario]['ensemble_prediction']
    
    # Plot
    fig, ax = plt.subplots(figsize=(14, 8))
    
    x = np.arange(n_scenarios)
    width = 0.15
    
    for i, model in enumerate(model_names + ['Ensemble']):
        offset = (i - n_models/2) * width
        ax.bar(x + offset, data[i], width, label=model, alpha=0.8)
    
    ax.set_xlabel('Scenario', fontsize=12)
    ax.set_ylabel('Win Probability', fontsize=12)
    ax.set_title('Model Predictions Across Different Scenarios', fontsize=14, pad=20)
    ax.set_xticks(x)
    ax.set_xticklabels(scenarios, rotation=45, ha='right')
    ax.legend()
    ax.grid(axis='y', alpha=0.3)
    ax.set_ylim([0, 1])
    
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'scenario_predictions.png', dpi=300, bbox_inches='tight')
    print(f"Saved: scenario_predictions.png")
    plt.close()

def plot_sensitivity_analysis(sensitivity_results, feature_cols):
    """Plot sensitivity analysis results"""
    n_features = len(feature_cols)
    n_cols = 3
    n_rows = (n_features + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(18, 4*n_rows))
    axes = axes.flatten()
    
    for idx, feature in enumerate(feature_cols):
        if feature not in sensitivity_results:
            axes[idx].axis('off')
            continue
        
        ax = axes[idx]
        data = sensitivity_results[feature]
        
        for model_name, predictions in data['predictions'].items():
            ax.plot(data['test_values'], predictions, marker='o', label=model_name, linewidth=2)
        
        ax.set_xlabel(feature, fontsize=10)
        ax.set_ylabel('Win Probability', fontsize=10)
        ax.set_title(f'Sensitivity: {feature}', fontsize=11)
        ax.legend(fontsize=8)
        ax.grid(alpha=0.3)
        ax.set_ylim([0, 1])
    
    # Hide unused subplots
    for idx in range(n_features, len(axes)):
        axes[idx].axis('off')
    
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'sensitivity_analysis.png', dpi=300, bbox_inches='tight')
    print(f"Saved: sensitivity_analysis.png")
    plt.close()

def main():
    print("=" * 60)
    print("Task 6: Synthetic Data Testing")
    print("=" * 60)
    print()
    
    # Load models and features
    print("Loading models and features...")
    models, feature_cols = load_models_and_features()
    print(f"Features: {feature_cols}\n")
    
    # Create scenario tests
    print("Creating test scenarios...")
    scenarios = create_scenario_tests(feature_cols)
    print(f"Created {len(scenarios)} scenarios\n")
    
    # Test scenarios
    print("Testing scenarios...")
    scenario_results = test_scenarios(models, scenarios, feature_cols)
    
    for scenario_name, result in scenario_results.items():
        print(f"\n{scenario_name}:")
        print(f"  Ensemble: {result['ensemble_prediction']:.3f}")
        for model, pred in result['predictions'].items():
            print(f"  {model}: {pred:.3f}")
    
    print()
    
    # Plot scenario results
    print("Creating scenario visualization...")
    plot_scenario_results(scenario_results)
    print()
    
    # Test sensitivity
    print("Performing sensitivity analysis...")
    base_scenario = scenarios['Strong Favorite']
    sensitivity_results = test_sensitivity(models, feature_cols, base_scenario)
    print(f"Analyzed sensitivity for {len(sensitivity_results)} features\n")
    
    # Plot sensitivity analysis
    print("Creating sensitivity visualization...")
    plot_sensitivity_analysis(sensitivity_results, feature_cols)
    print()
    
    # Save results
    results = {
        'scenario_tests': scenario_results,
        'sensitivity_analysis': sensitivity_results
    }
    
    with open(OUTPUT_DIR / 'testing_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    print(f"Saved: testing_results.json")
    
    print("\n" + "=" * 60)
    print("Task 6 Complete!")
    print("=" * 60)

if __name__ == '__main__':
    main()
