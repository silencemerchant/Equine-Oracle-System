#!/usr/bin/env python3.11
"""
Task 2: Feature Correlation Analysis
Analyzes feature relationships and identifies multicollinearity
"""

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import json
from pathlib import Path

# Set up paths
MODELS_DIR = Path('/home/ubuntu/equine_oracle/server/prediction_engine/models')
OUTPUT_DIR = Path('/home/ubuntu/analysis/feature_correlation')

def generate_synthetic_data(feature_cols, n_samples=1000):
    """Generate synthetic data for correlation analysis"""
    np.random.seed(42)
    
    # Create realistic synthetic data based on feature characteristics
    data = {}
    
    # Distance: 1000-3200 meters
    data['distance_numeric'] = np.random.uniform(1000, 3200, n_samples)
    
    # Days since last race: 7-90 days
    data['days_since_last_race'] = np.random.exponential(21, n_samples).clip(7, 90)
    
    # Career starts: 1-100
    data['career_starts'] = np.random.poisson(20, n_samples).clip(1, 100)
    
    # Average position L5: 1-12 (lower is better)
    data['avg_position_L5'] = np.random.gamma(3, 2, n_samples).clip(1, 12)
    
    # Win rate: 0-0.5 (most horses have low win rates)
    data['win_rate_cumulative'] = np.random.beta(2, 10, n_samples).clip(0, 0.5)
    
    # Race class score: 0-5
    data['race_class_score'] = np.random.choice([0, 1, 2, 3, 4, 5], n_samples, p=[0.3, 0.25, 0.2, 0.15, 0.07, 0.03])
    
    # Track popularity: 0-1
    data['track_popularity'] = np.random.beta(3, 2, n_samples)
    
    # Average perf index L5: -2 to 2
    data['avg_perf_index_L5'] = np.random.normal(0, 0.8, n_samples).clip(-2, 2)
    
    # Weighted form score: 0-100
    # Correlated with win_rate and avg_position_L5
    data['weighted_form_score'] = (
        50 + 
        data['win_rate_cumulative'] * 80 - 
        (data['avg_position_L5'] - 6) * 5 + 
        np.random.normal(0, 10, n_samples)
    ).clip(0, 100)
    
    df = pd.DataFrame(data)
    return df

def analyze_correlations(df, feature_cols):
    """Calculate and analyze feature correlations"""
    # Calculate correlation matrix
    corr_matrix = df[feature_cols].corr()
    
    # Find highly correlated pairs (|r| > 0.7)
    high_corr = []
    for i in range(len(corr_matrix.columns)):
        for j in range(i+1, len(corr_matrix.columns)):
            if abs(corr_matrix.iloc[i, j]) > 0.7:
                high_corr.append({
                    'feature1': corr_matrix.columns[i],
                    'feature2': corr_matrix.columns[j],
                    'correlation': float(corr_matrix.iloc[i, j])
                })
    
    return corr_matrix, high_corr

def plot_correlation_matrix(corr_matrix):
    """Create correlation matrix heatmap"""
    plt.figure(figsize=(12, 10))
    
    # Create mask for upper triangle
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
    
    # Create heatmap
    sns.heatmap(
        corr_matrix,
        mask=mask,
        annot=True,
        fmt='.2f',
        cmap='coolwarm',
        center=0,
        square=True,
        linewidths=1,
        cbar_kws={'shrink': 0.8}
    )
    
    plt.title('Feature Correlation Matrix', fontsize=16, pad=20)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'correlation_matrix.png', dpi=300, bbox_inches='tight')
    print(f"Saved: correlation_matrix.png")
    plt.close()

def plot_feature_distributions(df, feature_cols):
    """Plot distributions of all features"""
    n_features = len(feature_cols)
    n_cols = 3
    n_rows = (n_features + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(15, 4*n_rows))
    axes = axes.flatten()
    
    for idx, feature in enumerate(feature_cols):
        ax = axes[idx]
        ax.hist(df[feature], bins=30, edgecolor='black', alpha=0.7)
        ax.set_xlabel(feature)
        ax.set_ylabel('Frequency')
        ax.set_title(f'Distribution: {feature}')
        ax.grid(axis='y', alpha=0.3)
    
    # Hide unused subplots
    for idx in range(n_features, len(axes)):
        axes[idx].axis('off')
    
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'feature_distributions.png', dpi=300, bbox_inches='tight')
    print(f"Saved: feature_distributions.png")
    plt.close()

def calculate_vif(df, feature_cols):
    """Calculate Variance Inflation Factor for multicollinearity detection"""
    from sklearn.linear_model import LinearRegression
    
    vif_data = []
    
    for i, feature in enumerate(feature_cols):
        # Use other features to predict this feature
        X = df[feature_cols].drop(columns=[feature])
        y = df[feature]
        
        # Fit linear regression
        model = LinearRegression()
        model.fit(X, y)
        
        # Calculate R²
        r_squared = model.score(X, y)
        
        # Calculate VIF
        if r_squared < 0.9999:  # Avoid division by zero
            vif = 1 / (1 - r_squared)
        else:
            vif = float('inf')
        
        vif_data.append({
            'feature': feature,
            'vif': float(vif),
            'r_squared': float(r_squared)
        })
    
    return vif_data

def main():
    print("=" * 60)
    print("Task 2: Feature Correlation Analysis")
    print("=" * 60)
    print()
    
    # Load feature columns
    feature_cols = joblib.load(MODELS_DIR / 'feature_columns.pkl')
    print(f"Loaded {len(feature_cols)} feature columns")
    print(f"Features: {feature_cols}\n")
    
    # Generate synthetic data
    print("Generating synthetic data for analysis...")
    df = generate_synthetic_data(feature_cols, n_samples=1000)
    print(f"Generated {len(df)} samples\n")
    
    # Analyze correlations
    print("Analyzing feature correlations...")
    corr_matrix, high_corr = analyze_correlations(df, feature_cols)
    
    if high_corr:
        print(f"Found {len(high_corr)} highly correlated pairs (|r| > 0.7):")
        for pair in high_corr:
            print(f"  {pair['feature1']} <-> {pair['feature2']}: {pair['correlation']:.3f}")
    else:
        print("No highly correlated pairs found (|r| > 0.7)")
    print()
    
    # Plot correlation matrix
    print("Creating correlation matrix visualization...")
    plot_correlation_matrix(corr_matrix)
    print()
    
    # Plot feature distributions
    print("Creating feature distribution plots...")
    plot_feature_distributions(df, feature_cols)
    print()
    
    # Calculate VIF
    print("Calculating Variance Inflation Factors...")
    vif_data = calculate_vif(df, feature_cols)
    
    print("\nVIF Results:")
    for item in sorted(vif_data, key=lambda x: x['vif'], reverse=True):
        print(f"  {item['feature']}: VIF={item['vif']:.2f}, R²={item['r_squared']:.3f}")
    print()
    
    # Save results
    results = {
        'correlation_matrix': corr_matrix.to_dict(),
        'high_correlations': high_corr,
        'vif_scores': vif_data,
        'summary_statistics': df.describe().to_dict()
    }
    
    with open(OUTPUT_DIR / 'correlation_analysis.json', 'w') as f:
        json.dump(results, f, indent=2)
    print(f"Saved: correlation_analysis.json")
    
    print("\n" + "=" * 60)
    print("Task 2 Complete!")
    print("=" * 60)

if __name__ == '__main__':
    main()
