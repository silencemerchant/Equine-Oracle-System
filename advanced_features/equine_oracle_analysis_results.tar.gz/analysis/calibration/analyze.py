#!/usr/bin/env python3.11
"""
Task 4: Prediction Calibration Analysis
Assesses probability calibration and confidence score reliability
"""

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import json
from pathlib import Path
from sklearn.calibration import calibration_curve
from sklearn.metrics import brier_score_loss

# Set up paths
MODELS_DIR = Path('/home/ubuntu/equine_oracle/server/prediction_engine/models')
OUTPUT_DIR = Path('/home/ubuntu/analysis/calibration')

def load_models():
    """Load classification models"""
    models = {}
    model_files = {
        'LightGBM': 'lightgbm_model.pkl',
        'XGBoost': 'xgboost_model.pkl',
        'Random Forest': 'random_forest_model.pkl',
        'Gradient Boosting': 'gradient_boosting_model.pkl'
    }
    
    for name, filename in model_files.items():
        try:
            models[name] = joblib.load(MODELS_DIR / filename)
            print(f"Loaded {name}")
        except Exception as e:
            print(f"Error loading {name}: {e}")
    
    return models

def generate_test_data(n_samples=1000):
    """Generate synthetic test data with known probabilities"""
    np.random.seed(42)
    
    # Generate features
    X = np.random.randn(n_samples, 9)
    
    # Generate true probabilities
    linear_combination = (
        X[:, 0] * 0.3 +
        X[:, 3] * -0.4 +
        X[:, 4] * 0.5 +
        X[:, 8] * 0.3
    )
    
    true_probs = 1 / (1 + np.exp(-linear_combination))
    
    # Generate binary outcomes
    y = (np.random.rand(n_samples) < true_probs).astype(int)
    
    return X, y, true_probs

def analyze_calibration(models, X, y):
    """Analyze calibration for each model"""
    calibration_data = {}
    
    for name, model in models.items():
        if hasattr(model, 'predict_proba'):
            # Get predicted probabilities
            pred_proba = model.predict_proba(X)[:, 1]
            
            # Calculate calibration curve
            fraction_of_positives, mean_predicted_value = calibration_curve(
                y, pred_proba, n_bins=10, strategy='uniform'
            )
            
            # Calculate Brier score
            brier = brier_score_loss(y, pred_proba)
            
            calibration_data[name] = {
                'fraction_of_positives': fraction_of_positives.tolist(),
                'mean_predicted_value': mean_predicted_value.tolist(),
                'brier_score': float(brier),
                'predicted_probabilities': pred_proba.tolist()
            }
            
            print(f"{name}:")
            print(f"  Brier Score: {brier:.4f}")
            print(f"  Mean predicted prob: {pred_proba.mean():.4f}")
            print(f"  Actual positive rate: {y.mean():.4f}")
            print()
    
    return calibration_data

def plot_calibration_curves(calibration_data):
    """Create calibration curve plots"""
    fig, axes = plt.subplots(2, 2, figsize=(14, 12))
    axes = axes.flatten()
    
    for idx, (name, data) in enumerate(calibration_data.items()):
        if idx >= 4:
            break
            
        ax = axes[idx]
        
        # Plot calibration curve
        ax.plot(
            data['mean_predicted_value'],
            data['fraction_of_positives'],
            marker='o',
            linewidth=2,
            label=f'{name} (Brier: {data["brier_score"]:.3f})'
        )
        
        # Plot perfect calibration line
        ax.plot([0, 1], [0, 1], linestyle='--', color='gray', label='Perfect Calibration')
        
        ax.set_xlabel('Mean Predicted Probability', fontsize=11)
        ax.set_ylabel('Fraction of Positives', fontsize=11)
        ax.set_title(f'Calibration Curve: {name}', fontsize=12)
        ax.legend(loc='lower right')
        ax.grid(alpha=0.3)
        ax.set_xlim([0, 1])
        ax.set_ylim([0, 1])
    
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'calibration_curves.png', dpi=300, bbox_inches='tight')
    print(f"Saved: calibration_curves.png")
    plt.close()

def plot_probability_distributions(calibration_data, y):
    """Plot predicted probability distributions"""
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes = axes.flatten()
    
    for idx, (name, data) in enumerate(calibration_data.items()):
        if idx >= 4:
            break
            
        ax = axes[idx]
        
        pred_proba = np.array(data['predicted_probabilities'])
        
        # Separate by actual class
        pos_probs = pred_proba[y == 1]
        neg_probs = pred_proba[y == 0]
        
        # Plot histograms
        ax.hist(neg_probs, bins=30, alpha=0.5, label='Actual Negative', color='red')
        ax.hist(pos_probs, bins=30, alpha=0.5, label='Actual Positive', color='blue')
        
        ax.set_xlabel('Predicted Probability', fontsize=11)
        ax.set_ylabel('Frequency', fontsize=11)
        ax.set_title(f'Probability Distribution: {name}', fontsize=12)
        ax.legend()
        ax.grid(axis='y', alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'probability_distributions.png', dpi=300, bbox_inches='tight')
    print(f"Saved: probability_distributions.png")
    plt.close()

def analyze_confidence_scores(calibration_data, y):
    """Analyze confidence score reliability"""
    confidence_analysis = {}
    
    for name, data in calibration_data.items():
        pred_proba = np.array(data['predicted_probabilities'])
        
        # Calculate confidence as max(p, 1-p)
        confidence = np.maximum(pred_proba, 1 - pred_proba)
        
        # Bin by confidence level
        bins = [0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
        bin_labels = ['50-60%', '60-70%', '70-80%', '80-90%', '90-100%']
        
        bin_analysis = []
        
        for i in range(len(bins) - 1):
            mask = (confidence >= bins[i]) & (confidence < bins[i+1])
            
            if mask.sum() > 0:
                bin_probs = pred_proba[mask]
                bin_y = y[mask]
                
                # Predict 1 if prob > 0.5, else 0
                bin_preds = (bin_probs > 0.5).astype(int)
                accuracy = (bin_preds == bin_y).mean()
                
                bin_analysis.append({
                    'confidence_range': bin_labels[i],
                    'n_samples': int(mask.sum()),
                    'accuracy': float(accuracy),
                    'mean_confidence': float(confidence[mask].mean())
                })
        
        confidence_analysis[name] = bin_analysis
    
    return confidence_analysis

def plot_confidence_analysis(confidence_analysis):
    """Plot confidence vs accuracy"""
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes = axes.flatten()
    
    for idx, (name, data) in enumerate(confidence_analysis.items()):
        if idx >= 4:
            break
            
        ax = axes[idx]
        
        if data:
            ranges = [d['confidence_range'] for d in data]
            accuracies = [d['accuracy'] for d in data]
            confidences = [d['mean_confidence'] for d in data]
            
            x = np.arange(len(ranges))
            
            ax.bar(x, accuracies, alpha=0.7, label='Accuracy')
            ax.plot(x, confidences, marker='o', color='red', linewidth=2, label='Mean Confidence')
            
            ax.set_xlabel('Confidence Range', fontsize=11)
            ax.set_ylabel('Score', fontsize=11)
            ax.set_title(f'Confidence vs Accuracy: {name}', fontsize=12)
            ax.set_xticks(x)
            ax.set_xticklabels(ranges, rotation=45)
            ax.legend()
            ax.grid(axis='y', alpha=0.3)
            ax.set_ylim([0, 1])
    
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / 'confidence_analysis.png', dpi=300, bbox_inches='tight')
    print(f"Saved: confidence_analysis.png")
    plt.close()

def main():
    print("=" * 60)
    print("Task 4: Prediction Calibration Analysis")
    print("=" * 60)
    print()
    
    # Load models
    print("Loading models...")
    models = load_models()
    print()
    
    # Generate test data
    print("Generating test data...")
    X, y, true_probs = generate_test_data(n_samples=1000)
    print(f"Generated {len(X)} samples")
    print(f"True positive rate: {y.mean():.4f}\n")
    
    # Analyze calibration
    print("Analyzing calibration...")
    calibration_data = analyze_calibration(models, X, y)
    
    # Plot calibration curves
    print("\nCreating calibration curve plots...")
    plot_calibration_curves(calibration_data)
    
    # Plot probability distributions
    print("Creating probability distribution plots...")
    plot_probability_distributions(calibration_data, y)
    
    # Analyze confidence scores
    print("\nAnalyzing confidence scores...")
    confidence_analysis = analyze_confidence_scores(calibration_data, y)
    
    for name, data in confidence_analysis.items():
        print(f"\n{name}:")
        for bin_data in data:
            print(f"  {bin_data['confidence_range']}: "
                  f"n={bin_data['n_samples']}, "
                  f"acc={bin_data['accuracy']:.3f}, "
                  f"conf={bin_data['mean_confidence']:.3f}")
    
    # Plot confidence analysis
    print("\nCreating confidence analysis plots...")
    plot_confidence_analysis(confidence_analysis)
    
    # Save results
    results = {
        'calibration_data': {
            name: {
                'brier_score': data['brier_score'],
                'calibration_curve': {
                    'fraction_of_positives': data['fraction_of_positives'],
                    'mean_predicted_value': data['mean_predicted_value']
                }
            }
            for name, data in calibration_data.items()
        },
        'confidence_analysis': confidence_analysis
    }
    
    with open(OUTPUT_DIR / 'calibration_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved: calibration_results.json")
    
    print("\n" + "=" * 60)
    print("Task 4 Complete!")
    print("=" * 60)

if __name__ == '__main__':
    main()
